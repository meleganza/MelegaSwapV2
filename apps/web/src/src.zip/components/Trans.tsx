import { Trans } from '@pancakeswap/localization'

export default Trans
