import { ChainId, Currency } from '@pancakeswap/sdk'
import { BinanceIcon, PolygonIcon, TokenLogo } from '@pancakeswap/uikit'
import { useMemo } from 'react'
import { WrappedTokenInfo } from '@pancakeswap/token-lists'
import styled from 'styled-components'
import { useHttpLocations } from '@pancakeswap/hooks'
import { BAD_SRCS } from './constants'
import getTokenLogoURL, { getTokenLogoPosition } from '../../utils/getTokenLogoURL'
import { useActiveChainId } from 'hooks/useActiveChainId'

const StyledLogo = styled(TokenLogo) <{ size: string }>`
  width: ${({ size }) => size};
  height: ${({ size }) => size};
  border-radius: 50%;
`

export default function CurrencyLogo({
  currency,
  size = '24px',
  style,
}: {
  currency?: Currency
  size?: string
  style?: React.CSSProperties
}) {
  const chainId = useActiveChainId()
  const uriLocations = useHttpLocations(currency instanceof WrappedTokenInfo ? currency.logoURI : undefined)
  const srcs: string[] = useMemo(() => {
    if (currency?.isNative) return []

    if (currency?.isToken) {
      const tokenLogoURL = getTokenLogoURL(currency)
      const tokenLogoPosition = getTokenLogoPosition(currency)

      if (currency instanceof WrappedTokenInfo) {
        if (!tokenLogoURL) return [...uriLocations]
        return [...uriLocations, tokenLogoURL, tokenLogoPosition]
      }
      if (!tokenLogoURL) return [tokenLogoPosition]
      return [tokenLogoURL, tokenLogoPosition]
    }
    return []
  }, [currency, uriLocations])

  if (currency?.isNative) {
    if (currency.chainId === ChainId.BSC) {
      return <BinanceIcon width={size} style={style} />
    } else if (currency.chainId === ChainId.BASE) {
      return (
        <StyledLogo
          badSrcs={BAD_SRCS}
          size={size}
          srcs={[`/images/chains/8453.png`]}
          width={size}
          style={style}
        />
      )
    } else if (currency.chainId === ChainId.POLYGON) {
      return (
        <StyledLogo
          badSrcs={BAD_SRCS}
          size={size}
          srcs={[`/images/chains/137.png`]}
          width={size}
          style={style}
        />
      )
    }
    return (
      <StyledLogo
        badSrcs={BAD_SRCS}
        size={size}
        srcs={[`/images/${chainId}/tokens/${currency.chainId}.png`]}
        width={size}
        style={style}
      />
    )
  }

  return (
    <StyledLogo badSrcs={BAD_SRCS} size={size} srcs={srcs} alt={`${currency?.symbol ?? 'token'} logo`} style={style} />
  )
}
