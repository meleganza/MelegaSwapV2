export const BAD_SRCS: { [imageSrc: string]: true } = {}
