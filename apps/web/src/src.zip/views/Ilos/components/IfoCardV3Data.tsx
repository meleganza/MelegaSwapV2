import React from 'react'
import useGetPublicIfoData from 'views/Ilos/hooks/v3/useGetPublicIfoData'
import { Ifo } from 'config/constants/types'
import IfoFoldableCard from './IfoFoldableCard'


const IfoCardV3Data: React.FC = () => {

  return (
    <div/>
  )
}

export default IfoCardV3Data
