import styled from 'styled-components'

const IfoLayout = styled.div`
  display: flex;
  padding: 40px 0;
  
`

export default IfoLayout
