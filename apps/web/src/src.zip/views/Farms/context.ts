import { createContext } from 'react'

export const FarmsContext = createContext({ chosenFarmsMemoized: [] })
