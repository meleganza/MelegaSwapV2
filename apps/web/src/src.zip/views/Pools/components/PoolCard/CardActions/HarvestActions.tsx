import { Pool } from '@pancakeswap/uikit'
import CollectModal from '../../Modals/CollectModal'

export default Pool.withCollectModalCardAction(CollectModal)
