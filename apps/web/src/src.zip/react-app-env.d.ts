type SerializedBigNumber = string

declare let __NEZHA_BRIDGE__: any

declare module '*.png'
declare module '*.svg'
declare module '*.jpeg'
declare module '*.jpg'
